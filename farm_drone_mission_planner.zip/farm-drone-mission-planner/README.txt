
# Farm Drone Mission Planner (WordPress Plugin)

Shortcode: [farm_drone_planner]

Features:
- Client-side drone mission planner UI for Crop Scouting, Spraying, Livestock Monitoring.
- Draw or import a field polygon (GeoJSON) or upload an aerial image.
- Generate a lawnmower-style grid of waypoints based on spacing (meters).
- Place problem markers on the map and attach notes + images.
- Generate a mission report and export CSV (waypoints + markers) and PDF (report snapshot) client-side.
- All exports are performed in the browser; no server uploads by default.

Installation:
1. Upload the `farm-drone-mission-planner` folder to your WordPress `wp-content/plugins/` directory, or install the provided ZIP from Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Add the shortcode `[farm_drone_planner]` to a page or post to show the planner UI.

Notes & next steps:
- The plugin uses Leaflet (map), html2canvas and jsPDF via CDN. If your site blocks CDNs, these can be bundled locally into `assets/vendor` and the enqueue URLs updated.
- This initial version performs client-only planning. If you want server-side storage of missions, user accounts, integrations with drone autopilot file exporters (DJI, PX4/Mission Planner), or automated image analysis (ML), I can add those features.
