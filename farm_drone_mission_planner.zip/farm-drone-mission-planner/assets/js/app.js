
// Farm Drone Mission Planner - client-side app
(function(){
    // Leaflet map
    let map = null;
    let drawnPolygon = null;
    let polygonLayer = null;
    let gridLayer = null;
    let markers = []; // {lat,lng,label,notes,imageDataURL}
    let waypoints = []; // [{lat,lng}]
    let addingMarkerMode = false;
    const spacingInput = document.getElementById('fdm_spacing');
    const mapDiv = document.getElementById('fdm_map');
    const imagePreview = document.getElementById('fdm_image_preview');
    const geoUpload = document.getElementById('fdm_geojson_upload');
    const imgUpload = document.getElementById('fdm_map_image');
    const drawBtn = document.getElementById('fdm_draw_polygon');
    const genGridBtn = document.getElementById('fdm_generate_grid');
    const addMarkerBtn = document.getElementById('fdm_add_marker');
    const generateReportBtn = document.getElementById('fdm_generate_report');
    const csvBtn = document.getElementById('fdm_download_csv');
    const pdfBtn = document.getElementById('fdm_download_pdf');
    const reportDiv = document.getElementById('fdm_report');
    const reportContent = document.getElementById('fdm_report_content');
    const fieldNameInput = document.getElementById('fdm_field_name');
    const missionType = document.getElementById('fdm_mission_type');

    function initMap(){
        map = L.map(mapDiv, { center: [29.0, 69.0], zoom: 6 });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        polygonLayer = L.layerGroup().addTo(map);
        gridLayer = L.layerGroup().addTo(map);

        map.on('click', function(e){
            if(addingMarkerMode){
                const label = (markers.length + 1).toString();
                const marker = L.marker(e.latlng, { draggable: false }).addTo(polygonLayer);
                marker.bindPopup('<b>Marker '+label+'</b><br/><textarea placeholder="Notes" rows="3" style="width:160px;"></textarea><br/><input type="file" accept="image/*" />');
                marker.on('popupopen', function(p){
                    const popupNode = p.popup.getElement();
                    const textarea = popupNode.querySelector('textarea');
                    const fileInput = popupNode.querySelector('input[type=file]');
                    const idx = markers.length;
                    fileInput.addEventListener('change', (ev)=>{
                        const f = ev.target.files[0];
                        if(!f) return;
                        const reader = new FileReader();
                        reader.onload = (ev2)=>{
                            markers[idx].imageDataURL = ev2.target.result;
                        };
                        reader.readAsDataURL(f);
                    });
                    textarea.addEventListener('change', ()=>{
                        markers[idx].notes = textarea.value;
                    });
                });
                markers.push({lat: e.latlng.lat, lng: e.latlng.lng, label: label, notes: '', imageDataURL: null});
                addingMarkerMode = false;
                addMarkerBtn.textContent = 'Add Problem Marker';
            }
        });
    }

    function enablePolygonDrawing(){
        alert('Click on the map to add polygon vertices. Double click to finish the polygon.');
        let pts = [];
        let tempLine = null;
        function onMapClick(e){
            pts.push([e.latlng.lat, e.latlng.lng]);
            if(pts.length > 1){
                if(tempLine) map.removeLayer(tempLine);
                tempLine = L.polyline(pts).addTo(polygonLayer);
            } else {
                L.circleMarker(pts[0]).addTo(polygonLayer);
            }
        }
        function finish(){
            map.off('click', onMapClick);
            map.off('dblclick', finish);
            if(tempLine) map.removeLayer(tempLine);
            if(pts.length >= 3){
                if(drawnPolygon) polygonLayer.removeLayer(drawnPolygon);
                drawnPolygon = L.polygon(pts).addTo(polygonLayer);
                map.fitBounds(drawnPolygon.getBounds());
            } else {
                alert('Polygon requires at least 3 points.');
            }
        }
        map.on('click', onMapClick);
        map.on('dblclick', finish);
    }

    // Simple grid generator: creates parallel lines across bounding box and sample points every spacing meters
    function generateGrid(){
        if(!drawnPolygon){
            alert('Draw or load a field polygon first.');
            return;
        }
        const spacing = parseFloat(spacingInput.value) || 20;
        gridLayer.clearLayers();
        waypoints = [];

        const bounds = drawnPolygon.getBounds();
        // create a simple grid of points within bounds and test if inside polygon
        // approx meters per degree at map center
        const centerLat = bounds.getCenter().lat;
        const metersPerDegLat = 111320;
        const metersPerDegLng = 40075000 * Math.cos(centerLat * Math.PI/180) / 360.0;
        const latSpacing = spacing / metersPerDegLat;
        const lngSpacing = spacing / metersPerDegLng;

        const minLat = bounds.getSouth();
        const maxLat = bounds.getNorth();
        const minLng = bounds.getWest();
        const maxLng = bounds.getEast();

        let toggle = false;
        for(let lat = minLat; lat <= maxLat; lat += latSpacing){
            let row = [];
            if(!toggle){
                for(let lng = minLng; lng <= maxLng; lng += lngSpacing){
                    row.push([lat,lng]);
                }
            } else {
                for(let lng = maxLng; lng >= minLng; lng -= lngSpacing){
                    row.push([lat,lng]);
                }
            }
            toggle = !toggle;
            row.forEach(pt => {
                const latlng = L.latLng(pt[0], pt[1]);
                if(drawnPolygon && drawnPolygon.getBounds().contains(latlng) && leafletPIP_containsPoint(drawnPolygon.getLatLngs()[0], latlng)){
                    waypoints.push({lat: pt[0], lng: pt[1]});
                    L.circleMarker([pt[0], pt[1]], { radius:2 }).addTo(gridLayer);
                }
            });
        }
        // Draw polyline through waypoints
        const wpLatLngs = waypoints.map(w=>[w.lat, w.lng]);
        if(wpLatLngs.length > 0){
            L.polyline(wpLatLngs, { color: '#0073aa' }).addTo(gridLayer);
        }
        alert('Generated '+waypoints.length+' waypoints.');
    }

    // point-in-polygon for leaflets latlngs array
    function leafletPIP_containsPoint(polyLatLngs, point){
        // ray casting
        const x = point.lng, y = point.lat;
        let inside = false;
        for(let i=0,j=polyLatLngs.length-1;i<polyLatLngs.length;j=i++){
            const xi = polyLatLngs[i].lng, yi = polyLatLngs[i].lat;
            const xj = polyLatLngs[j].lng, yj = polyLatLngs[j].lat;
            const intersect = ((yi>y) != (yj>y)) && (x < (xj - xi) * (y - yi) / (yj - yi + 0.0) + xi);
            if(intersect) inside = !inside;
        }
        return inside;
    }

    // CSV and PDF export
    function downloadCSV(report){
        const rows = [];
        rows.push(['Field','Mission','Generated At','Waypoint Index','Waypoint Lat','Waypoint Lng','Marker Label','Marker Lat','Marker Lng','Marker Notes','Marker Image (filename)']);
        const generated = new Date().toISOString();
        const maxRows = Math.max(waypoints.length, markers.length, 1);
        for(let i=0;i<maxRows;i++){
            const wp = waypoints[i] || {};
            const mk = markers[i] || {};
            rows.push([report.field_name, report.mission_type, generated, i+1, wp.lat||'', wp.lng||'', mk.label||'', mk.lat||'', mk.lng||'', mk.notes||'', (mk.imageDataURL?('embedded_image_'+(i+1)+'.png'):'')]);
        }
        const csvContent = rows.map(r => r.map(c => '"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
        const blob = new Blob([csvContent], {type: 'text/csv;charset=utf-8;'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (report.field_name?report.field_name.replace(/\s+/g,'_')+'_':'') + 'drone_mission.csv';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    }

    async function downloadPDF(report){
        const printable = document.createElement('div');
        printable.style.padding = '10px';
        printable.style.fontFamily = 'Arial, sans-serif';
        printable.innerHTML = '<h2>Farm Drone Mission Report</h2>';
        printable.innerHTML += '<strong>Field:</strong> '+(report.field_name||'—')+'<br/>';
        printable.innerHTML += '<strong>Mission:</strong> '+report.mission_type+'<br/>';
        printable.innerHTML += '<strong>Generated:</strong> '+report.generated_at+'<br/>';
        printable.innerHTML += '<h3>Waypoints</h3>';
        if(waypoints.length === 0){
            printable.innerHTML += '<div>No waypoints.</div>';
        } else {
            printable.innerHTML += '<ol>';
            waypoints.forEach((w, i)=>{ printable.innerHTML += '<li>WP '+(i+1)+': '+w.lat.toFixed(6)+', '+w.lng.toFixed(6)+'</li>'; });
            printable.innerHTML += '</ol>';
        }
        printable.innerHTML += '<h3>Problem Markers</h3>';
        if(markers.length === 0){
            printable.innerHTML += '<div>No markers.</div>';
        } else {
            markers.forEach((m,i)=>{
                printable.innerHTML += '<div><b>Marker '+m.label+'</b>: '+(m.lat.toFixed(6))+', '+(m.lng.toFixed(6))+'<br/>Notes: '+(m.notes||'')+'</div>';
                if(m.imageDataURL){
                    const img = new Image();
                    img.src = m.imageDataURL;
                    img.style.maxWidth = '280px';
                    img.style.display = 'block';
                    img.style.marginTop = '6px';
                    printable.appendChild(img);
                }
            });
        }

        // include a snapshot of the map
        const mapClone = mapDiv.cloneNode(true);
        mapClone.style.width = '600px';
        mapClone.style.height = '400px';
        printable.appendChild(mapClone);

        document.body.appendChild(printable);
        await new Promise(r=>setTimeout(r,400));
        const canvas = await html2canvas(printable, {scale:2});
        const imgData = canvas.toDataURL('image/jpeg', 0.95);
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF('p','pt','a4');
        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();
        const img = new Image();
        img.src = imgData;
        await new Promise((res)=>{ img.onload = res; });
        const ratio = Math.min(pageWidth / img.width, pageHeight / img.height);
        const imgW = img.width * ratio;
        const imgH = img.height * ratio;
        pdf.addImage(imgData, 'JPEG', 20, 20, imgW-40, imgH-40);
        const filename = (report.field_name?report.field_name.replace(/\s+/g,'_')+'_':'') + 'drone_mission_report.pdf';
        pdf.save(filename);
        printable.remove();
    }

    function buildReportObject(){
        return {
            field_name: fieldNameInput.value || '',
            mission_type: missionType.value || '',
            generated_at: new Date().toISOString(),
            waypoints_count: waypoints.length,
            markers_count: markers.length
        };
    }

    // GeoJSON loader
    geoUpload.addEventListener('change', (e)=>{
        const f = e.target.files[0];
        if(!f) return;
        const reader = new FileReader();
        reader.onload = (ev)=>{
            try{
                const geo = JSON.parse(ev.target.result);
                if(drawnPolygon) polygonLayer.removeLayer(drawnPolygon);
                if(geo.type === 'FeatureCollection' && geo.features && geo.features.length){
                    const coords = geo.features[0].geometry.coordinates[0];
                    const latlngs = coords.map(c=>[c[1], c[0]]);
                    drawnPolygon = L.polygon(latlngs).addTo(polygonLayer);
                    map.fitBounds(drawnPolygon.getBounds());
                } else if(geo.type === 'Polygon' && geo.coordinates){
                    const coords = geo.coordinates[0];
                    const latlngs = coords.map(c=>[c[1], c[0]]);
                    drawnPolygon = L.polygon(latlngs).addTo(polygonLayer);
                    map.fitBounds(drawnPolygon.getBounds());
                } else {
                    alert('GeoJSON polygon not found in file.');
                }
            }catch(err){ alert('Invalid GeoJSON'); }
        };
        reader.readAsText(f);
    });

    // Image upload preview (aerial)
    imgUpload.addEventListener('change', (e)=>{
        const f = e.target.files[0];
        if(!f) return;
        const reader = new FileReader();
        reader.onload = (ev)=>{
            imagePreview.innerHTML = '';
            const img = document.createElement('img');
            img.src = ev.target.result;
            img.style.maxWidth = '100%';
            img.style.maxHeight = '100%';
            imagePreview.appendChild(img);
        };
        reader.readAsDataURL(f);
    });

    // Button events
    drawBtn.addEventListener('click', ()=> enablePolygonDrawing());
    genGridBtn.addEventListener('click', ()=> generateGrid());
    addMarkerBtn.addEventListener('click', ()=> {
        addingMarkerMode = true;
        addMarkerBtn.textContent = 'Click map to place marker';
    });

    generateReportBtn.addEventListener('click', ()=>{
        const report = buildReportObject();
        renderReport(report);
        reportDiv.style.display = 'block';
    });
    csvBtn.addEventListener('click', ()=>{
        const report = buildReportObject();
        downloadCSV(report);
    });
    pdfBtn.addEventListener('click', async ()=>{
        const report = buildReportObject();
        await downloadPDF(report);
    });

    function renderReport(report){
        reportContent.innerHTML = '';
        const p = document.createElement('div');
        p.innerHTML = '<strong>Field:</strong> '+(report.field_name||'—') + '<br/>' +
                      '<strong>Mission:</strong> '+report.mission_type + '<br/>' +
                      '<strong>Generated:</strong> '+report.generated_at + '<br/>' +
                      '<strong>Waypoints:</strong> '+report.waypoints_count + '<br/>' +
                      '<strong>Markers:</strong> '+report.markers_count + '<br/>';
        reportContent.appendChild(p);
    }

    // init
    initMap();

})();
